package exceptions;

public class InvalidHabitException extends Exception {
    public InvalidHabitException(String message) {
        super(message);
    }
}
